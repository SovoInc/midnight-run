# Midnight Wallet API

This API provides a comprehensive interface for wallet operations, defining the structure of the wallet state, the methods for interacting with it, and the types and variables used within. It is implemented by the [@midnight-ntwrk/wallet](https://www.npmjs.com/package/@midnight-ntwrk/wallet) package.

For detailed information, please visit the [API reference documentation](https://docs.midnight.network/develop/reference/midnight-api/wallet-api/).
