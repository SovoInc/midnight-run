**@midnight-ntwrk/wallet-api v5.0.0-rc.1** • Readme \| [API](globals.md)

***

# Midnight Wallet API

This API provides a comprehensive interface for wallet operations, defining the structure of the wallet state, the methods for interacting with it, and the types and variables used within. It is implemented by the `@midnight-ntwrk/wallet` package.

See the [Midnight wallet developer guide](https://docs.midnight.network/develop/guides/wallet-dev-guide) for implementation and usage information.
